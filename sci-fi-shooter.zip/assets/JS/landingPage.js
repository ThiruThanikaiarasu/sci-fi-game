const closeTab = () => {
    window.close()
}

